
const messagesContainer = document.getElementById("messagesContainer");

async function loadMessages() {

    try {

        const response = await fetch("/api/messages");

        const messages = await response.json();

        if (messages.length === 0) {

            messagesContainer.innerHTML = `
                <p>No messages submitted yet.</p>
            `;

            return;
        }

        messagesContainer.innerHTML = "";

        messages.forEach((item, index) => {

            const messageCard = document.createElement("div");

            messageCard.className = "message-card";

            messageCard.innerHTML = `
                <h3>Message ${index + 1}</h3>

                <p>
                    <strong>Name:</strong>
                    ${item.name}
                </p>

                <p>
                    <strong>Email:</strong>
                    ${item.email}
                </p>

                <p>
                    <strong>Message:</strong>
                    ${item.message}
                </p>

                <p>
                    <strong>Date:</strong>
                    ${item.date}
                </p>
            `;

            messagesContainer.appendChild(messageCard);

        });

    } catch (error) {

        console.error(error);

        messagesContainer.innerHTML = `
            <p>Unable to load messages.</p>
        `;
    }
}

loadMessages();

