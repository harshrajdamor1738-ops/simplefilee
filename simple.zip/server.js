
const express = require("express");
const fs = require("fs");
const path = require("path");

const app = express();

const PORT = 3000;

const messagesFile = path.join(__dirname, "messages.json");

app.use(express.json());

app.use(express.static(__dirname));

function getMessages() {

    if (!fs.existsSync(messagesFile)) {

        fs.writeFileSync(
            messagesFile,
            JSON.stringify([], null, 2)
        );

        return [];
    }

    const data = fs.readFileSync(messagesFile, "utf8");

    if (!data.trim()) {
        return [];
    }

    try {
        return JSON.parse(data);
    } catch (error) {

        console.log("messages.json contains invalid data.");

        return [];
    }
}


app.post("/api/contact", (req, res) => {

    const { name, email, message } = req.body;

    if (!name || !email || !message) {

        return res.status(400).json({
            success: false,
            message: "Please fill all fields."
        });

    }

    const messages = getMessages();

    const newMessage = {
        id: Date.now(),
        name: name.trim(),
        email: email.trim(),
        message: message.trim(),
        date: new Date().toLocaleString()
    };

    messages.push(newMessage);

    fs.writeFileSync(
        messagesFile,
        JSON.stringify(messages, null, 2)
    );

    res.json({
        success: true,
        message: "Message sent successfully!"
    });

});


app.get("/api/messages", (req, res) => {

    const messages = getMessages();

    res.json(messages);

});


app.get("/api/messages/count", (req, res) => {

    const messages = getMessages();

    res.json({
        count: messages.length
    });

});


app.listen(PORT, () => {

    console.log("");
    console.log("=================================");
    console.log("     Node.js Server Started");
    console.log("=================================");
    console.log("");
    console.log(`Website: http://localhost:${PORT}`);
    console.log(`Messages: http://localhost:${PORT}/messages.html`);
    console.log("");
});

